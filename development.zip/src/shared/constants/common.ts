// import intl from 'react-intl-universal';

export const PRODUCT_NAME = '数据服务API';

export const defaultRequestHeaderContentType = 'text/json';

export const events = {
  PASSING_SELECTION: 'passing_selected_text',
};

export const defaultResultTableDataKey = undefined; // data or undefined



